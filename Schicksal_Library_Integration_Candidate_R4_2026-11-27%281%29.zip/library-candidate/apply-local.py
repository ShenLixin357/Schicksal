#!/usr/bin/env python3
"""Apply to a clean, local checkout only. Never pushes or deploys."""
import argparse, hashlib, json, pathlib, re, shutil, subprocess
BASE='e31fe637aeb629bb0a2cf42223041f2c0755871a'
parser=argparse.ArgumentParser();parser.add_argument('checkout',type=pathlib.Path);parser.add_argument('--branch',default='feature/library-integration-20261127');parser.add_argument('--check',action='store_true',help='check anchors without any writes');a=parser.parse_args();root=a.checkout.resolve();package=pathlib.Path(__file__).resolve().parent

def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
if git('rev-parse','HEAD')!=BASE:raise SystemExit('基线不一致；需人工同步并复核冲突。拒绝自动修改。')
if git('status','--porcelain'):raise SystemExit('工作树不干净。拒绝修改。')
if not a.check and git('branch','--list',a.branch):raise SystemExit('目标分支已存在。拒绝覆盖。')
# Reject differences even when a clean checkout has an unexpected base file.
for rel,expected in json.loads((package/'docs/BASELINE_R4.json').read_text())['verified_files'].items():
 data=(root/rel).read_bytes();actual=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
 if actual!=expected:raise SystemExit(f'主站文件哈希不符: {rel}')
# Verify that the compiled library catalog and the seven canonical Markdown originals correspond.
public=package/'overlay/public'; catalog=json.loads((public/'library/data/nation-building.json').read_text())
if len(catalog['chapters'])!=7:raise SystemExit('国家书正文不完整')
for chapter in catalog['chapters']:
 source=(public/chapter['source'].lstrip('/')).resolve()
 if not source.is_relative_to(public.resolve()) or hashlib.sha256(source.read_bytes()).hexdigest()!=chapter['sha256']:
  raise SystemExit(f'正文与馆藏索引不一致: {chapter["id"]}')
# Preflight every change before creating branch or writing. Preserve existing main archive bytes.
changes={}
for f in (package/'overlay').rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(package/'overlay');target=root/rel
 if target.exists() and target.read_bytes()!=f.read_bytes():raise SystemExit(f'现有文件内容不同，拒绝覆盖: {rel}')
 if not target.exists():changes[target]=f.read_bytes()

def replace_once(source,old,new,count=1):
 if source.count(old)!=count:raise SystemExit(f'主站锚点已变化，停止: {old[:110]}')
 return source.replace(old,new)
page=root/'app/page.tsx';s=page.read_text();anchor='const ArchivesSection = lazy(() => import("./archives/archive-section").then(module => ({ default: module.ArchivesSection })));';s=replace_once(s,anchor,anchor+'\nconst LibrarySection = lazy(() => import("./library/library-section").then(module => ({ default: module.LibrarySection })));');s=replace_once(s,'case "library": content = <ShellPlaceholder kind="library" />; break;','case "library": content = <FeatureSuspense label="天命图书馆" onExit={() => setSection("home")}><LibrarySection technology={accountMode === "technology" && isCurrentMinister}/></FeatureSuspense>; break;');s=replace_once(s,'onOpenPhotos={() => setSection("photos")} onBack','onOpenPhotos={() => setSection("photos")} onOpenLibrary={() => setSection("library")} onBack',2);s=replace_once(s,'\n\n// Only import these data-heavy sections when the user navigates to them.','\n// Only import these data-heavy sections when the user navigates to them.');assert len(s.split('\n'))<=650, 'page.tsx line budget';changes[page]=s.encode()
archives=root/'app/archives/archive-section.tsx';s=archives.read_text();s=replace_once(s,'import { PageHead } from "../shell/page-head";','import { PageHead } from "../shell/page-head";\nimport chapterMetadata from "../library/archive-chapters.json";');pattern=r'const ARCHIVE_BOOK_CHAPTERS: ArchiveChapter\[\] = \[.*?\n\];';s,n=re.subn(pattern,'const ARCHIVE_BOOK_CHAPTERS: ArchiveChapter[] = chapterMetadata;',s,flags=re.S);assert n==1
# Original reader could get stuck in loading when selecting the same chapter again.
# Also cancel prior network reads on chapter changes/close and never show a stale chapter.
s=replace_once(s,'  const [chapterText, setChapterText] = useState("");','  const [chapterText, setChapterText] = useState("");\n  const [loadedSource, setLoadedSource] = useState("");')
s=replace_once(s,'    let active = true;\n    fetch(chapter.source)','    let active = true; const controller = new AbortController();\n    setLoading(true); setArchiveStatus("");\n    fetch(chapter.source, { signal: controller.signal })')
s=replace_once(s,'if (active) setChapterText(text);','if (active) { setChapterText(text); setLoadedSource(chapter.source); }')
s=replace_once(s,'return () => { active = false; };','return () => { active = false; controller.abort(); };')
s=replace_once(s,'const selectChapter = (index: number) => { setLoading(true); setArchiveStatus(""); setChapterIndex(index); };','const selectChapter = (index: number) => { if (index !== chapterIndex || !bookOpen) { setLoading(true); setArchiveStatus(""); setChapterIndex(index); } };')
s=replace_once(s,'{loading ? <div className="reader-loading">','{loading || (loadedSource !== chapter.source && !archiveStatus) ? <div className="reader-loading">')
changes[archives]=s.encode()
tech=root/'app/technology/technology-ministry.tsx';s=tech.read_text();s=replace_once(s,'{ sharedMark, onOpenPhotos, onBack }','{ sharedMark, onOpenPhotos, onOpenLibrary, onBack }');s=replace_once(s,'  onOpenPhotos: () => void;','  onOpenPhotos: () => void;\n  onOpenLibrary: () => void;');anchor='<MemberAccessSettings />';s=replace_once(s,anchor,'<button type="button" onClick={onOpenLibrary}>进入图书馆调试 <span aria-hidden="true">→</span></button>\n          '+anchor);changes[tech]=s.encode()
# Update the existing regression test that deliberately required a placeholder before the feature was built.
shell=root/'tests/shell-preview.test.mjs';s=shell.read_text();s=replace_once(s,'assert.match(page, /case "library": content = <ShellPlaceholder/);','assert.match(page, /case "library": content = <FeatureSuspense[^\\n]*<LibrarySection/);\n  assert.match(page, /const LibrarySection = lazy\\(\\(\\) => import\\("\\.\\/library\\/library-section"\\)/);');changes[shell]=s.encode()
# Keep the canonical identity test suite running the actual route against its existing SQLite + session helpers.
auth=root/'tests/identity-boundary.test.mjs';s=auth.read_text();s=replace_once(s,'hooks.deregister();','const libraryDebug = await import("../app/api/library/debug/route.ts");\nhooks.deregister();');s+='\n'+(package/'tests/main-auth-extension.txt').read_text();changes[auth]=s.encode()
boundary=root/'scripts/architecture/check-boundaries.mjs';s=boundary.read_text();s=replace_once(s,'"parliament", "club"];','"parliament", "club", "library"];');s=replace_once(s,'for (const feature of ["./parliament/parliament-section", "./club/committee-lounge"])','for (const feature of ["./parliament/parliament-section", "./club/committee-lounge", "./library/library-section"])');changes[boundary]=s.encode()
# Existing architecture regression tests must assert the new canonical catalog rather than hardcoded source paths in JSX.
arch_test=root/'tests/architecture-phase1.test.mjs';s=arch_test.read_text()
for lesson in ['1','2-a','2-b']:
 old=f'assert.match(archive, /how-to-build-a-state-lesson-{lesson}\\.md/);'
 s=replace_once(s,old,f'assert.match(catalog, /how-to-build-a-state-lesson-{lesson}\\.md/);')
s=replace_once(s,'  assert.match(archive, /archive-queen-cover\\.png/);','  assert.match(archive, /archive-queen-cover\\.png/);\n  const catalog = read("app/library/archive-chapters.json");\n  assert.match(archive, /import chapterMetadata/);\n  assert.equal(JSON.parse(catalog).length, 7);')
changes[arch_test]=s.encode()
# Extend real existing private Worker regression to cover the new library scripts, manuscripts and artwork.
private=root/'tests/private-site.test.mjs';s=private.read_text()
s=replace_once(s,'"/archives/how-to-build-a-state-lesson-1.md", "/favicon.svg"','"/archives/how-to-build-a-state-lesson-1.md", "/archives/how-to-build-a-state-lesson-6.md", "/library/library/catalog/mount.js", "/library/data/nation-building.json", "/library/assets/master/library-master-v1.png", "/favicon.svg"')
changes[private]=s.encode()
# Run the installed module's regression suite on every main-site npm test, not only the external candidate fixture.
package_json=root/'package.json';data=json.loads(package_json.read_text())
if 'test:library' in data['scripts'] or not data['scripts']['test'].endswith('npm run test:briefing'):raise SystemExit('主站测试脚本已变化，请复核')
data['scripts']['test']+=' && npm run test:library';data['scripts']['test:library']='node --test tests/library-data.test.mjs'
changes[package_json]=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
# Do not change deployment scripts or migrations. All writes are strictly local.
if a.check:
 print(f'PASS baseline and all integration anchors; {len(changes)} proposed files; no writes.');raise SystemExit(0)
subprocess.run(['git','-C',str(root),'switch','-c',a.branch],check=True)
for path,content in changes.items():path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(content)
print(f'已写入本地独立分支 {a.branch}，{len(changes)} 个文件。尚未构建、提交或推送。')
