#!/usr/bin/env bash
# Run ONLY on an authorized clean local copy with no production secrets/bindings.
# This script creates an isolated local branch, not a remote branch or deployment.
set -euo pipefail
if [[ $# -ne 1 ]]; then echo 'Usage: bash run-main-local.sh /path/to/clean/Schicksal'; exit 2; fi
PACKAGE="$(cd -- "$(dirname -- "$0")" && pwd)"
CHECKOUT="$(cd -- "$1" && pwd)"
python3 "$PACKAGE/apply-local.py" "$CHECKOUT" --check
python3 "$PACKAGE/apply-local.py" "$CHECKOUT"
cd "$CHECKOUT"
git diff --check
npm ci
npm run build
npm test
AUTH_SOURCE_ROOT="$CHECKOUT" node --experimental-transform-types --test "$PACKAGE/tests/permissions-local.mjs"
node --experimental-default-type=module --test "$PACKAGE/tests/library-data.test.mjs"
echo 'Local build and tests passed. Review changes and browser test gates before any commit/push. No deployment or database operation was requested or run.'
