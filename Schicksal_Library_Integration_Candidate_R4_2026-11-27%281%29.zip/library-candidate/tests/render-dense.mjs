// Native Canvas 2D smoke harness; not a browser/DOM acceptance test.
import {createRequire} from 'node:module';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);
const {Canvas,Image,Path2D}=require(process.env.SKIA_CANVAS_MODULE||'skia-canvas');
globalThis.Path2D=Path2D;
const files=new Set();
const originalFetch=globalThis.fetch;
globalThis.document={createElement(tag){assert.equal(tag,'canvas');return new Canvas(1,1)}};
globalThis.Image=class {
 set src(value){const image=new Image();const path=fileURLToPath(value);files.add(path);image.src=readFileSync(path);image.decode().then(()=>this.onload?.(),e=>this.onerror?.(e));this.native=image;}
 get width(){return this.native.width} get height(){return this.native.height} get naturalWidth(){return this.native.width} get naturalHeight(){return this.native.height}
};
// Unwrap HTMLImageElement shim at the native Canvas boundary.
const proto=Object.getPrototypeOf(new Canvas(1,1).getContext('2d'));
const draw=proto.drawImage;proto.drawImage=function(image,...args){return draw.call(this,image instanceof Canvas?image:image?.native??image,...args)};
globalThis.fetch=async function(url,options){if(String(url).startsWith('file:')){const path=fileURLToPath(url);files.add(path);return new Response(readFileSync(path),{status:200});}return originalFetch(url,options);};
const {loadSceneHost}=await import('../overlay/public/library/library/catalog/scene-host.js');
const {BOOK_IDS,bindingForBook}=await import('../overlay/public/library/library/catalog/documents.js');
const room=new Canvas(1671,941);let reduced=true;const stage=await loadSceneHost(room,{reduced:()=>reduced});
const out=resolve(process.argv[2]||'render-dense');mkdirSync(out,{recursive:true});
stage.render(0,0,null);const base=Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data);let sampleCount=0;const summary=[];let ambient=0;
for(const id of BOOK_IDS){const t=stage.setBook(bindingForBook(id));const fps=['L3','R2','R3','R4','AVS'].includes(id)?12:8;let samples=0,covered=0;const hard=['R2','R3','R4','AVS'].includes(id);const sheet=hard?new Canvas(4*418,3*235):null;const sc=sheet?.getContext('2d');const total=Math.ceil(t.finish*fps);reduced=false;
for(let i=0;i<=total;i++){const time=Math.min(t.finish,i/fps);ambient+=1000/fps;stage.render(ambient,time,null);const st=t.sample(time);if(st.behindCrest)covered++;const px=room.getContext('2d').getImageData(0,0,1,1).data;assert.equal(px[3],255);if(st.pose)for(const k of ['x','y','scale','heading','pitch','lean'])assert(Number.isFinite(st.pose[k]),`${id} ${k} @ ${time}`);if(hard&&i%Math.max(1,Math.ceil(total/12))===0){const j=Math.floor(i/Math.max(1,Math.ceil(total/12)));if(j<12){sc.drawImage(room,(j%4)*418,Math.floor(j/4)*235,418,235);sc.fillStyle='#18141f';sc.fillRect((j%4)*418,Math.floor(j/4)*235,96,20);sc.font='14px sans-serif';sc.fillStyle='white';sc.fillText(`${id} ${time.toFixed(2)}s`,(j%4)*418+3,Math.floor(j/4)*235+15);}}samples++;}
if(sheet)await sheet.toFile(resolve(out,`${id}-sequence.jpg`));stage.reset();reduced=true;stage.render(ambient,0,null);assert.deepEqual(Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data),base,`${id} exact restore`);sampleCount+=samples;summary.push({id,fps,frames:samples,seconds:t.finish,behindCrest:covered,restore:true});console.log('PASS',id,samples,'frames; exact restore; behind crest',covered);writeFileSync(resolve(out,'dense-summary.json'),JSON.stringify({sampleCount,summary,files:files.size},null,2));}
// Actual debug guide paint + final reset, including exact restore.
const guide=stage.setBook(bindingForBook('R3'));stage.setView({debugGuides:true,lockedCore:0});stage.render(ambient,guide.settled,null);await room.toFile(resolve(out,'debug-guides.jpg'));stage.setView({debugGuides:false,lockedCore:null});stage.reset();stage.render(ambient,0,null);assert.deepEqual(Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data),base);stage.dispose();console.log('PASS total',sampleCount,'sequential native frames;',files.size,'assets; guide rendering and restore');
