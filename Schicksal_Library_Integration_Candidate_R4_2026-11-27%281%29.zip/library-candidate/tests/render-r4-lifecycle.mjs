// Native Canvas 2D smoke harness; not a browser/DOM acceptance test.
import {createRequire} from 'node:module';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);
const {Canvas,Image,Path2D}=require(process.env.SKIA_CANVAS_MODULE||'skia-canvas');
globalThis.Path2D=Path2D;
const files=new Set();
const originalFetch=globalThis.fetch;
globalThis.document={createElement(tag){assert.equal(tag,'canvas');return new Canvas(1,1)}};
globalThis.Image=class {
 set src(value){const image=new Image();const path=fileURLToPath(value);files.add(path);image.src=readFileSync(path);image.decode().then(()=>this.onload?.(),e=>this.onerror?.(e));this.native=image;}
 get width(){return this.native.width} get height(){return this.native.height} get naturalWidth(){return this.native.width} get naturalHeight(){return this.native.height}
};
// Unwrap HTMLImageElement shim at the native Canvas boundary.
const proto=Object.getPrototypeOf(new Canvas(1,1).getContext('2d'));
const draw=proto.drawImage;proto.drawImage=function(image,...args){return draw.call(this,image instanceof Canvas?image:image?.native??image,...args)};
globalThis.fetch=async function(url,options){if(String(url).startsWith('file:')){const path=fileURLToPath(url);files.add(path);return new Response(readFileSync(path),{status:200});}return originalFetch(url,options);};
const {loadSceneHost}=await import('../overlay/public/library/library/catalog/scene-host.js');
const {BOOK_IDS,bindingForBook}=await import('../overlay/public/library/library/catalog/documents.js');
// Real Canvas, not browser: verify teardown and stable book restoration after host changes.
const room=new Canvas(1671,941), abort=new AbortController();
const stage=await loadSceneHost(room,{signal:abort.signal,reduced:()=>true});
stage.render(0,0,null);const base=Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data);
for(const id of BOOK_IDS){const trip=stage.setBook(bindingForBook(id));stage.render(0,trip.settled,null);stage.reset();stage.render(0,0,null);assert.deepEqual(Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data),base,id);console.log('PASS native settled and restored:',id);}
stage.dispose();stage.dispose();stage.render(0,0,null);console.log('PASS idempotent stage teardown');
const stopped=new AbortController();stopped.abort();const before=files.size;await assert.rejects(loadSceneHost(new Canvas(1671,941),{signal:stopped.signal}),e=>e.name==='AbortError');assert.equal(files.size,before);console.log('PASS cancelled load rejects');
const during=new AbortController();const loading=loadSceneHost(new Canvas(1671,941),{signal:during.signal});during.abort();await assert.rejects(loading,e=>e.name==='AbortError');console.log('PASS mid-load cancellation');console.log('PASS actual loaded files:',files.size);
