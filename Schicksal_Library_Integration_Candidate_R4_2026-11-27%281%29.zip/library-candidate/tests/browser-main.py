#!/usr/bin/env python3
"""Full main-shell smoke and library E2E. Requires an isolated local preview Worker + test-only D1.
Never point at production. Use an explicit local URL, an exact preview commit and preview-only credentials.
Run: SCHICKSAL_LOCAL_URL=http://127.0.0.1:8787 SCHICKSAL_LOCAL_SHA=<candidate SHA> \
     SCHICKSAL_TEST_MEMBER=amberina SCHICKSAL_TEST_PASSWORD=<test-only> \
     SCHICKSAL_TEST_TECH_PASSWORD=<separate test-only office password> \
     python tests/browser-main.py --engine chromium
Repeat with --engine webkit; use native Safari manual checks too.
"""
import argparse, os, re, json
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright, expect
p=argparse.ArgumentParser();p.add_argument('--engine',choices=['chromium','webkit'],required=True);p.add_argument('--executable');p.add_argument('--full-motion',action='store_true');a=p.parse_args()
base=os.environ.get('SCHICKSAL_LOCAL_URL','').rstrip('/');u=urlsplit(base)
assert u.scheme in ('http','https') and u.hostname in ('127.0.0.1','localhost','::1') and not u.path and not u.query and not u.fragment and not u.username and not u.password,'Only a local isolated Worker URL is allowed'
sha=os.environ.get('SCHICKSAL_LOCAL_SHA','');assert re.fullmatch('[0-9a-f]{40}',sha),'Exact candidate commit required'
member=os.environ.get('SCHICKSAL_TEST_MEMBER','amberina');password=os.environ.get('SCHICKSAL_TEST_PASSWORD','');tech_password=os.environ.get('SCHICKSAL_TEST_TECH_PASSWORD','');assert member in ('amberina','zxy','truth','kaito','harry') and password and tech_password and password!=tech_password,'Use distinct isolated member and office credentials'
ids=['A','L1','L2','L3','L4','R1','R2','R3','R4','LT','AVS'];title=lambda b:'如何从零建立一个国家' if b=='AVS' else b
with sync_playwright() as w:
 browser=getattr(w,a.engine).launch(**({'executable_path':a.executable} if a.executable else {}))
 def auth_request(page,path):return page.request.get(base+path,max_redirects=0)
 def login(page,office=False):
  response=page.goto(base,wait_until='domcontentloaded');assert response and response.status==401
  assert auth_request(page,'/library/data/nation-building.json').status==401
  assert auth_request(page,'/api/library/debug').status==401
  # Allow the approved opening to complete or skip normally; do not bypass briefing.
  skip=page.locator('#skip');
  if skip.is_visible():skip.click()
  expect(page.locator('#login')).to_be_visible(timeout=45000)
  page.locator('#identity-'+('technology' if office else member)).click();page.locator('#password').fill(tech_password if office else password);page.locator('#entry button[type=submit]').click()
  expect(page.locator('.mandatory-briefing-gate')).to_be_attached(timeout=45000);dialog=page.get_by_role('dialog',name='帝国简报');expect(dialog).to_be_visible(timeout=45000);expect(page.locator('#imperial-sidebar')).to_have_count(0)
  version=auth_request(page,'/api/preview-version');assert version.status==200 and version.json()=={'preview':True,'sourceSha':sha},'Wrong or unverified isolated candidate'
  page.get_by_role('button',name='关闭帝国简报，返回天命首页').click();expect(page.locator('#imperial-sidebar')).to_be_visible()
 def library(page):
  nav=page.locator('#imperial-collection-submenu');
  if not nav.is_visible():page.locator('button[title="帝国馆藏"]').click()
  nav.get_by_role('button',name='魔法图书馆',exact=True).click();room=page.locator('#room');expect(room).to_have_attribute('data-mode','idle',timeout=45000);expect(page.locator('[data-book]')).to_have_count(11);return room
 def read(page,book):
  expect(page.locator('#reader')).to_be_visible(timeout=35000);expect(page.locator('#book-title')).to_have_text(title(book));expect(page.locator('#reading-content')).to_contain_text('全书目录')
 def restore(page,room):
  page.locator('#return-button').click();expect(room).to_have_attribute('data-mode','idle',timeout=35000);expect(page.locator('#reader')).not_to_be_visible()
 def logout(page):
  r=page.request.delete(base+'/api/member-session',headers={'Origin':base},max_redirects=0);assert r.ok,'Test session revoke failed'
  assert auth_request(page,'/library/data/nation-building.json').status==401
 try:
  ctx=browser.new_context(viewport={'width':1440,'height':950},reduced_motion='reduce');page=ctx.new_page();requests=[];errors=[];failed=[]
  page.on('request',lambda r: requests.append(urlsplit(r.url).path));page.on('pageerror',lambda e: errors.append(str(e)));page.on('response',lambda r:failed.append((urlsplit(r.url).path,r.status)) if '/library/' in r.url and r.status>=400 and r.request.resource_type not in ('fetch','xhr') else None)
  try:
   login(page);assert not any(x.startswith('/library/') for x in requests if x!='/library/data/nation-building.json' and x!='/api/library/debug'),'Library loaded before navigation'
   assert auth_request(page,'/api/library/debug').status==403
   room=library(page);expect(page.locator('.library-debug')).to_have_count(0)
   for b in ids:
    page.locator('#crest').click();page.locator('#query').fill(title(b));page.locator(f'.result-main[data-book-id="{b}"][data-kind="contents"]').first.dblclick();read(page,b);page.locator('#cover-button').click();expect(page.locator('#cover')).to_be_visible();page.locator('#cover').press('ArrowRight');page.locator('#resume-button').click();restore(page,room)
   print('PASS 11 catalogue / reader / cover / return; ordinary member',flush=True)
   if a.full_motion:
    page.emulate_media(reduced_motion='no-preference')
    for b in ids:
     page.locator(f'[data-book="{b}"]').click();expect(room).to_have_attribute('data-mode','summoning');read(page,b);restore(page,room);print('PASS timed forward and return',b,flush=True)
   # Repeated navigation must unmount scene and leave session/mandatory gate unchanged.
   for i in range(3):
    page.locator('button[title="首页"]').click();expect(page.locator('#room')).to_have_count(0);expect(page.locator('.mandatory-briefing-gate')).to_have_count(0);room=library(page)
   nav=page.locator('#imperial-collection-submenu');nav.get_by_role('button',name='国家档案馆',exact=True).click();expect(page.locator('.archive-chapter-index nav button')).to_have_count(7);first=page.locator('.archive-chapter-index nav button').first;first.click();expect(page.locator('.archive-prose')).to_be_visible(timeout=15000);first.click();expect(page.locator('.archive-prose')).to_be_visible();print('PASS 7 shared archive chapters and same-chapter reselect',flush=True)
   # Verify main shell is still usable after library unmount.
   page.locator('button[title="帝国政务"]').click();page.get_by_text('Order Paper · 议事清单',exact=True).wait_for(state='visible',timeout=30000);expect(page.locator('#room')).to_have_count(0)
   assert not errors,errors;assert not failed,failed
  finally:
   try:logout(page)
   finally:ctx.close()
  ctx=browser.new_context(viewport={'width':1440,'height':950},reduced_motion='reduce');page=ctx.new_page()
  try:
   login(page,office=True);assert auth_request(page,'/api/library/debug').status==200
   page.locator('button[title="科技部管理台"]').click();page.get_by_role('button',name='进入图书馆调试').click();room=page.locator('#room');expect(room).to_have_attribute('data-mode','idle',timeout=45000)
   page.locator('.library-debug summary').click();page.get_by_label('调试书籍').select_option('R3');page.get_by_role('button',name='播放 / 继续',exact=True).click();expect(room).to_have_attribute('data-mode','debug');page.get_by_role('button',name='停止并归位',exact=True).click();expect(room).to_have_attribute('data-mode','idle');print('PASS real minister-only debug access and preview',flush=True)
  finally:
   try:logout(page)
   finally:ctx.close()
 finally:browser.close()
print('PASS isolated main shell browser suite:',a.engine,sha)
