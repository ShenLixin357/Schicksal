"""Real local browser tests. Run on authorized browser hosts; no production access.
python tests/browser-local.py --engine chromium --executable /path/to/chrome
python tests/browser-local.py --engine webkit
"""
import argparse, functools, http.server, pathlib, threading, tempfile, shutil
from playwright.sync_api import sync_playwright, expect
p=argparse.ArgumentParser();p.add_argument('--engine',choices=['chromium','webkit'],default='chromium');p.add_argument('--executable');a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];ids=['A','L1','L2','L3','L4','R1','R2','R3','R4','LT','AVS'];title=lambda x:'如何从零建立一个国家' if x=='AVS' else x
with tempfile.TemporaryDirectory() as folder:
 public=pathlib.Path(folder)/'public';shutil.copytree(root/'overlay/public',public)
 preview=(root/'local-preview/preview-local.html').read_text();(public/'library/preview-local.html').write_text(preview);(public/'library/preview-debug.html').write_text(preview.replace("getElementById('library'))","getElementById('library'),{debug:true})"))
 class Quiet(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(public)));threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}/library/'
 try:
  with sync_playwright() as w:
   browser=getattr(w,a.engine).launch(**({'executable_path':a.executable} if a.executable else {}));errors=[];failures=[]
   def load(page,path='preview-local.html'):
    page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:failures.append(f'{r.status}: {r.url}') if r.status>=400 and not r.url.endswith('/favicon.ico') else None)
    page.goto(base+path);expect(page.locator('#room')).to_have_attribute('data-mode','idle',timeout=30000);return page.locator('#room')
   def shelf(page,book):return page.locator(f'[data-book="{book}"]')
   def result(page,book):
    page.locator('#crest').click();page.locator('#query').fill(title(book));return page.locator(f'.result-main[data-book-id="{book}"][data-kind="contents"]').first
   def reading(page,book):
    expect(page.locator('#reader')).to_be_visible(timeout=35000);expect(page.locator('#book-title')).to_have_text(title(book));expect(page.locator('#reading-content')).to_contain_text('全书目录')
   def restore(page,room):
    page.locator('#return-button').click();expect(room).to_have_attribute('data-mode','idle',timeout=35000);expect(page.locator('#reader')).not_to_be_visible();expect(page.locator('[data-book]')).to_have_count(11)
   page=browser.new_page(viewport={'width':1440,'height':950},reduced_motion='reduce');room=load(page)
   for book in ids:
    result(page,book).dblclick();reading(page,book);page.locator('#cover-button').click();expect(page.locator('#cover')).to_be_visible();page.locator('#cover').press('ArrowRight');page.locator('#resume-button').click();restore(page,room);print('PASS catalog direct / cover / return',book,flush=True)
    shelf(page,book).dblclick();reading(page,book);restore(page,room)
   page.locator('#crest').click();page.locator('#query').fill('自由');page.locator('.result-main[data-block-id]').first.dblclick();expect(page.locator('#reader')).to_be_visible();expect(page.locator('#reading-content .search-hit')).to_be_visible();restore(page,room)
   shelf(page,'R1').focus();shelf(page,'R1').press('Enter');reading(page,'R1');restore(page,room);print('PASS keyboard, chapter anchor and reduced motion',flush=True)
   page.emulate_media(reduced_motion='no-preference')
   for i,book in enumerate(ids):
    if i%2:result(page,book).click()
    else:shelf(page,book).click()
    expect(room).to_have_attribute('data-mode','summoning');reading(page,book);restore(page,room);print('PASS complete timed forward and return',book,flush=True)
   shelf(page,'R2').click();expect(room).to_have_attribute('data-mode','summoning');page.locator('#skip').click();reading(page,'R2');restore(page,room)
   shelf(page,'R1').click();shelf(page,'L1').click();reading(page,'L1');restore(page,room);print('PASS quick switch and skip',flush=True)
   page.get_by_role('button',name='全屏查看',exact=True).click();expect(page.locator('#room')).to_be_visible();page.locator('#crest').click();expect(page.locator('#summon')).to_be_visible();page.locator('#close-catalog').click();expect(page.locator('#summon')).not_to_be_visible();page.keyboard.press('Escape');page.set_viewport_size({'width':1024,'height':768});expect(room).to_be_visible();page.set_viewport_size({'width':1440,'height':950});expect(page.locator('.library-debug')).to_have_count(0);page.evaluate('window.disposeLibrary()');expect(room).to_have_count(0);page.close();print('PASS fullscreen/resize/unmount, ordinary member has no debug UI (fixture only)',flush=True)
   touch=browser.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,reduced_motion='reduce');mobile=touch.new_page();room=load(mobile);shelf(mobile,'R3').tap();reading(mobile,'R3');restore(mobile,room);mobile.locator('#crest').tap();mobile.locator('#query').fill('R4');mobile.locator('.result-main').first.tap();reading(mobile,'R4');restore(mobile,room);touch.close();print('PASS touch viewport',flush=True)
   debug=browser.new_page(viewport={'width':1440,'height':950},reduced_motion='reduce');room=load(debug,'preview-debug.html');debug.locator('.library-debug summary').click();debug.get_by_label('调试书籍').select_option('R3');debug.get_by_role('button',name='播放 / 继续',exact=True).click();expect(room).to_have_attribute('data-mode','debug');debug.get_by_role('button',name='前进一帧 +1/60 s',exact=True).click();debug.get_by_role('button',name='停止并归位',exact=True).click();expect(room).to_have_attribute('data-mode','idle');debug.evaluate('window.disposeLibrary()');expect(room).to_have_count(0);debug.close();assert not errors,errors;assert not failures,failures;browser.close();print('PASS debug fixture and no page/network errors',flush=True)
 finally:server.shutdown()
