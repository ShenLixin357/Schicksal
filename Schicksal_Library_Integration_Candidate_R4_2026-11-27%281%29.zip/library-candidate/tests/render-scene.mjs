// Native Canvas 2D smoke harness; not a browser/DOM acceptance test.
import {createRequire} from 'node:module';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const require=createRequire(import.meta.url);
const {Canvas,Image,Path2D}=require(process.env.SKIA_CANVAS_MODULE||'skia-canvas');
globalThis.Path2D=Path2D;
const files=new Set();
const originalFetch=globalThis.fetch;
globalThis.document={createElement(tag){assert.equal(tag,'canvas');return new Canvas(1,1)}};
globalThis.Image=class {
 set src(value){const image=new Image();const path=fileURLToPath(value);files.add(path);image.src=readFileSync(path);image.decode().then(()=>this.onload?.(),e=>this.onerror?.(e));this.native=image;}
 get width(){return this.native.width} get height(){return this.native.height} get naturalWidth(){return this.native.width} get naturalHeight(){return this.native.height}
};
// Unwrap HTMLImageElement shim at the native Canvas boundary.
const proto=Object.getPrototypeOf(new Canvas(1,1).getContext('2d'));
const draw=proto.drawImage;proto.drawImage=function(image,...args){return draw.call(this,image instanceof Canvas?image:image?.native??image,...args)};
globalThis.fetch=async function(url,options){if(String(url).startsWith('file:')){const path=fileURLToPath(url);files.add(path);return new Response(readFileSync(path),{status:200});}return originalFetch(url,options);};
const {loadSceneHost}=await import('../overlay/public/library/library/catalog/scene-host.js');
const {BOOK_IDS,bindingForBook}=await import('../overlay/public/library/library/catalog/documents.js');
const room=new Canvas(1671,941);const stage=await loadSceneHost(room,{reduced:()=>true});
const out=resolve(process.argv[2]||'render-output');mkdirSync(out,{recursive:true});
async function save(name){await room.toFile(resolve(out,name+'.png'));}
stage.render(0,0,null);await save('idle');const base=Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data);let sampleCount=0;
for(const id of BOOK_IDS){const t=stage.setBook(bindingForBook(id));const samples=[0,...t.chapters.map(([,s])=>s),t.settled,t.closes,t.finish];for(let i=0;i<samples.length;i++){stage.render(i*33,samples[i],null);sampleCount++;const pixels=room.getContext('2d').getImageData(0,0,1,1);assert.equal(pixels.data[3],255);if(['R2','R3','R4','AVS'].includes(id)||samples[i]===t.settled)await save(`${id}-${String(i).padStart(2,'0')}`);}const cover=new Canvas(720,510);stage.drawCover(cover,.18,-.17);await cover.toFile(resolve(out,`${id}-cover.png`));stage.reset();stage.render(0,0,null);assert.deepEqual(Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data),base,`${id} full pixel restore`);console.log('rendered',id,samples.length,'samples');}
await save('restored');stage.setView({guides:true,compare:true});stage.render(0,0,null);stage.setView({guides:false,compare:false});stage.render(0,0,null);assert.deepEqual(Buffer.from(room.getContext('2d').getImageData(0,0,1671,941).data),base);for(const side of ['left','right']){const from=stage.position(side);stage.activateLadder(side);assert.notEqual(stage.position(side),from);stage.activateLadder(side);assert.notEqual(stage.position(side),from);stage.move(side,'home');assert.equal(stage.position(side),from);}stage.render(0,0,null);stage.dispose();assert.equal(files.size,58);console.log('PASS samples',sampleCount,'pixel-exact restore for each book, view reset, ladder controls');writeFileSync(resolve(out,'loaded-files.json'),JSON.stringify([...files].sort().map(x=>x.split('/overlay/public/')[1]),null,2));console.log('PASS native Canvas',files.size,'unique loaded files');
