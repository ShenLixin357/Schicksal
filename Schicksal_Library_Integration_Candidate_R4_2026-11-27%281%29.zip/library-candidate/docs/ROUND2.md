# Round 2 — 2026-11-27 · 本地候选深化

Status: **Native Canvas smoke PASS; real browser and host integration BLOCKED; production NO-GO.**

Main rechecked via GitHub connector: `89169ae7777586ecdb8991a0c017b357338de520`; repository still public. `git ls-remote` fails `Could not resolve host: github.com`. No remote branch, pushes, merges, deployment, production database/storage operations or R2 activation. This package supersedes the earlier local candidate but is not a complete site checkout.

Changes relative to candidate 1:
- `scene-host.js`: add ladder direction alternation, rail position and view state, core rotation pause, guide display, fixed debug core angle, explicit draw reset. All existing trip/math/occlusion implementations and assets unchanged.
- `mount.js`: add scene controls, banner 420ms long-press, ladder sliders, light group toggle, original comparison, fullscreen; add debug timeline, key stages, pause/play, speed, frame step, loop, guide, crest angle lock, import/export, reset. Close/unmount/hide cancel pending selection and timers; explicit repaint on reduced motion and return. Debug drafts remain session-local, no persistence or publish.
- `template.js` and `catalog.css`: scene plane keeps canvas/hotspot relative geometry in fullscreen. Layout changes are unverified in browser.
- `tests/render-scene.mjs`: real native Skia Canvas drawing harness, uses actual source renderer, decoded actual image bytes and actual masks. Not a browser or DOM simulation. With reduced motion fixing ambient frame, 108 sampled timepoints across 11 books and 11 covers, exact full pixel restoration after each book, view reset and ladder direction/return assertions. Actual 58 unique loaded resource files. `docs/native-render-results.txt`, `docs/native-loaded-files.json`, and contact sheet included. Contact sheet shows selected first-run samples (same locked routes and artwork), not proof of frame-by-frame visual parity.
- `tests/browser-local.py`: Playwright local fixture regression for catalogue, direct open, return, cover, body match, normal motion/skip, ordinary UI and teardown, console/network. Attempted in Chromium; managed policy `ERR_BLOCKED_BY_ADMINISTRATOR` before any navigation. No E2E pass claimed. Requires authorized browser environment; Safari/WebKit not executed.

## Commands
- `node --experimental-default-type=module --test tests/library-data.test.mjs` (16/16 pass).
- `SKIA_CANVAS_MODULE=/path/to/skia-canvas node --experimental-default-type=module tests/render-scene.mjs /path/to/output` (native render pass; require installed skia-canvas; renders sensitive local artwork, do not publish output).
- `python tests/browser-local.py --engine chromium --executable /path/to/chrome` (blocked in this environment; run in normal authorized development environment; alternatively --engine webkit).
- `python3 apply-local.py /path/to/clean/Schicksal` only for actual baseline checkout; if main changed, review and update anchors. Script not run on real main yet.

## Remaining gates
1. Real browser E2E desktop + touch + keyboard + reduced motion, all eleven normal-motion calls from shelf and crest, single/double click conflicts, close during flight, fast repeat, scroll and cover restore, correct pointer alignment/fullscreen, resize, overlay, renderer cleanup. Verify occlusion continuously with browser recordings; native sampled frames are not a complete visual check.
2. Verify original scene parity incl. all lights, banner animation, core, ladder; original independent Lab retains layer inventory and flag emblem replacement tooling; flag emblem replacement UI is not ported into candidate and remains outstanding if required. Debug guides are simplified visual paths, not exact original standalone debug UI. Do not silently change approved animation parameters.
3. Actual Schicksal clone, local isolated branch, apply integration, `npm ci`, full build, original full tests/architecture checks, worker assets MIME paths, server session/technology guard checks with ordinary + elevated + expired roles, real main regression. No public commit of private manuscripts/illustrations. If main has progressed, rebase/review without overwriting parallel work. Verify exact candidate SHA before any authorized preview. No production release.
4. Canonical Markdown and compiled catalog derived index: add deterministic reindex pipeline before dynamic edits; current static snapshots checked by hash. Phase II: D1 revisions and publish, Gallery storage adapter remains placeholder, R2 remains off.

Original handoff is still the complete master archive; keep it. `routes.js` SHA256 remains `8660ae65f1109f766c38cb5bff0d7f476e514ed3d8f3b656288a439a68afb79e`.
