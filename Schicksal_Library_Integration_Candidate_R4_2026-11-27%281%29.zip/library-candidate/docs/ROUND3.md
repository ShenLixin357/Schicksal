# Round 3 · 图书馆主站接入候选及验收缺口

**NO-GO for production.** 用户批准继续实现、测试，不批准合并 main、生产部署、生产数据库变更或 R2 开通。此包为本地增量，不是已经接入正式站的版本。原始 86 MB Library Lab 交接包仍须保存。

## 1. 最新主站与并行开发
- 本轮最后核验的 main 为 `f9b9fe8efc1a5bcdf2c3ac58c6cac8bf1e0957db`，仓库在检查时为 public。另一条开发线已更新 Loading 与科技部界面。不要使用 R2 候选包的旧基线 `89169ae...`。
- 只读核对真实源码全部接入锚点；实际 page.tsx 650 行，模拟应用挂载修改后仍 650 行，保留现有 Loading。现有三份课稿 Git blob 哈希与 overlay 一致。记录见 BASELINE_R3.json、anchor-check-r3.txt。
- apply-local.py 增加精确 Git blob 检查、--check 无写入模式，更新原占位符回归测试，并把实际权限路由加入主站 SQLite 权限测试。未在真实 checkout 运行：Git DNS 受限，完整 checkout 与项目依赖不可用。不能声称主站 npm ci / vinext build / npm test 已通过。
- run-main-local.sh 供有完整本地开发环境时执行。此脚本不 push、不部署、不迁移、不包含生产密钥。基线已变化则先重新评审，禁止强行应用。

## 2. 权限
- 实际候选 GET /api/library/debug 调用主站 requireTechnologyMinister。前端必须收到明确 authorized:true, mode:local-preview-only, publish:false 才挂载调试器；提升授权存续期间每30秒/重新可见复核，拒绝或网络失败降级普通模式。草稿仅会话内存，不存入正式配置。
- permissions-local.mjs 对 7 个从真实 main 读取、逐字节匹配 Git blob 的源文件运行实际 session / office / route 逻辑。Cloudflare env.DB 用内存 SQLite 替代，表结构为本测试所需的最小结构；不是远程 D1，也不是全套迁移。verification/main-auth-snapshot 仅测试来源，不在 overlay。
- 8/8 测试组通过：无 session/伪造 cookie、普通成员/普通部长身份/非现任提升、合法现任、会话过期/授权过期、换届、无现任/多人现任异常、D1 故障、无写入/发布处理器。GET 状态 401/403/200/503 和 no-store 已验证。真实 Worker/登录浏览器 E2E 尚未验证。静态调试 JS 不是秘密；本地自改 JS 不等于服务端权限，任何未来保存或发布都必须再次服务端授权。

## 3. 动画、调试器、运行时
- render-dense.mjs 使用真实 Native Canvas（skia-canvas）和原始素材，非浏览器。11本连续 1,278 帧，普通8 fps、L3/R2/R3/R4/AVS 12 fps。全部加载58项资源、有限坐标、归位整幅像素一致。遮挡状态计数及序列见 render-r3/dense-summary.json、JPG，导引层实际绘制与复位也通过。序列图仅抽样，不足以证明每帧美术视觉与Safari完全一致。
- 原调试器的箭头、前后遮挡路径虚线、时间标记、当前阶段、路线标签、徽记角度输出、精确 +1/60s、.001 时间轴、点击书位切换与即时参数重建已补入；本地试换旗帜 PNG/WebP（8MB，16MP 上限）及复原仅在授权调试态显示，不上传/不发布。独立 Lab 的原始库存、视频及开发素材继续保留；持久化发布按用户确认留第二阶段。未对所有控件逐项完成真实浏览器验收。
- 修复单击/触摸二次点击竞争、不同书位快速切换、旗帜计时取消、隐藏页暂停调试、离开全屏、动画/Canvas/RAF清理、异步资源完成后的卸载检查、调试动态控制监听释放。18/18数据与生命周期单元测试通过，新增触摸选择和轨道逆向/取消 RAF；不能等同实际触屏、浏览器内存/GC测试。
- routes.js SHA-256 `8660ae65f1109f766c38cb5bff0d7f476e514ed3d8f3b656288a439a68afb79e` 保持原始定稿。七份课稿、十本占位书、四核心对象与未来 Gallery/R2 接口均保留。

## 4. 实际浏览器阻碍
- Chromium 启动成功但 localhost 导航 ERR_BLOCKED_BY_ADMINISTRATOR（管理策略），未执行任何 DOM 用例。Playwright WebKit 未安装，启动失败。见 chromium-r3.txt、webkit-r3.txt。没有改动环境管理策略，没有绕过访问限制。
- tests/browser-local.py 已覆盖11书目录/书位双击、正常连续往返、跳过、键盘、正文命中、封皮、触屏、全屏/resize、卸载、调试控件、console/network；待授权浏览器环境执行。该 fixture 仅用于本地功能验收，不能替代主站登录和实际 Safari/Chrome 验收。

## 5. 完成门槛
1. 先将本包应用到真实私密/本地 checkout，完成 npm ci、build、全站测试、主站 session 权限回归。
2. 用真实 Safari/Chrome 和触屏运行所有脚本及人工核对连续遮挡/视觉、内存快照、全屏退回和路由离开复位；验证主站首次进入图书馆才请求素材。
3. 确认主站最新基线、隔离整合分支和候选 SHA。GitHub public 不得推送私人艺术与稿件，等用户关闭公开或仅本地验收。预览需独立 Worker/D1 并明确批准，不能覆盖另一条开发线。
4. 不准生产 merge/deploy/D1 迁移。正式 Gallery、D1 动态正文/索引重建、参数持久化发布与 R2 均仍在后续阶段。

## 6. 本地复现
- `node --experimental-default-type=module --test tests/library-data.test.mjs`
- `node --experimental-transform-types --test tests/permissions-local.mjs`（内附真实 main 认证源码镜像）
- `SKIA_CANVAS_MODULE=/path/to/skia-canvas node --experimental-default-type=module tests/render-dense.mjs /path/to/output`
- `python tests/browser-local.py --engine chromium --executable /path/to/chrome`; `python tests/browser-local.py --engine webkit`
- `python3 apply-local.py /path/to/clean/Schicksal --check`; 经授权本地执行 `bash run-main-local.sh /path/to/clean/Schicksal`。
